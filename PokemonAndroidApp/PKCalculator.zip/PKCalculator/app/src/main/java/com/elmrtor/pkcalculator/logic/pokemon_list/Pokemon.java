package com.elmrtor.pkcalculator.logic.pokemon_list;

import java.util.List;
import java.util.Objects;

public class Pokemon {

    public enum PokemonType {
        BUG,
        DRAGON,
        ELECTRIC,
        FIGHTING,
        FIRE,
        FLYING,
        GHOST,
        GRASS,
        GROUND,
        ICE,
        NORMAL,
        POISON,
        PSYCHIC,
        ROCK,
        WATER
    }


    
    private int pokemonId;
    private String pokemonName;
    private String pokemonPictureLink;
    private int healthPoints;
    private int attackPoints;
    private int defensePoints;
    private int speedPoints;
    private int specialAttack;
    private int specialDefense;
    private int totalPoints;
    private int totalPointsGenOne;
    private List<PokemonType> pokemonTypes;


    @Override
    public String toString() {
        return "Pokemon{" +
                "pokemonId=" + pokemonId +
                ", pokemonName='" + pokemonName + '\'' +
                ", pokemonPictureLink='" + pokemonPictureLink + '\'' +
                ", healthPoints=" + healthPoints +
                ", attackPoints=" + attackPoints +
                ", defensePoints=" + defensePoints +
                ", speedPoints=" + speedPoints +
                ", specialAttack=" + specialAttack +
                ", specialDefense=" + specialDefense +
                ", totalPoints=" + totalPoints +
                ", totalPointsGenOne=" + totalPointsGenOne +
                ", pokemonTypes=" + pokemonTypes +
                '}';
    }

    public Pokemon() {

    }

    public String getPokemonPictureLink() {
        return pokemonPictureLink;
    }

    public void setPokemonPictureLink(String pokemonPictureLink) {
        this.pokemonPictureLink = pokemonPictureLink;
    }

    public int getPokemonId() {
        return pokemonId;
    }

    public void setPokemonId(int pokemonId) {
        this.pokemonId = pokemonId;
    }

    public String getPokemonName() {
        return pokemonName;
    }

    public void setPokemonName(String pokemonName) {
        this.pokemonName = pokemonName;
    }

    public int getHealthPoints() {
        return healthPoints;
    }

    public void setHealthPoints(int healthPoints) {
        this.healthPoints = healthPoints;
    }

    public int getAttackPoints() {
        return attackPoints;
    }

    public void setAttackPoints(int attackPoints) {
        this.attackPoints = attackPoints;
    }

    public int getDefensePoints() {
        return defensePoints;
    }

    public void setDefensePoints(int defensePoints) {
        this.defensePoints = defensePoints;
    }

    public int getSpeedPoints() {
        return speedPoints;
    }

    public void setSpeedPoints(int speedPoints) {
        this.speedPoints = speedPoints;
    }

    public int getSpecialAttack() {
        return specialAttack;
    }

    public void setSpecialAttack(int specialAttack) {
        this.specialAttack = specialAttack;
    }

    public int getSpecialDefense() {
        return specialDefense;
    }

    public void setSpecialDefense(int specialDefense) {
        this.specialDefense = specialDefense;
    }

    public int getTotalPoints() {
        return totalPoints;
    }

    public void setTotalPoints(int totalPoints) {
        this.totalPoints = totalPoints;
    }

    public int getTotalPointsGenOne() {
        return totalPointsGenOne;
    }

    public void setTotalPointsGenOne(int totalPointsGenOne) {
        this.totalPointsGenOne = totalPointsGenOne;
    }

    public List<PokemonType> getPokemonTypes() {
        return pokemonTypes;
    }

    public void setPokemonTypes(List<PokemonType> pokemonTypes) {
        this.pokemonTypes = pokemonTypes;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pokemon pokemon = (Pokemon) o;
        return pokemonId == pokemon.pokemonId &&
                healthPoints == pokemon.healthPoints &&
                attackPoints == pokemon.attackPoints &&
                defensePoints == pokemon.defensePoints &&
                speedPoints == pokemon.speedPoints &&
                specialAttack == pokemon.specialAttack &&
                specialDefense == pokemon.specialDefense &&
                totalPoints == pokemon.totalPoints &&
                totalPointsGenOne == pokemon.totalPointsGenOne &&
                Objects.equals(pokemonName, pokemon.pokemonName) &&
                Objects.equals(pokemonTypes, pokemon.pokemonTypes);
    }

    @Override
    public int hashCode() {
        return Objects.hash(pokemonId, pokemonName, healthPoints, attackPoints, defensePoints, speedPoints, specialAttack, specialDefense, totalPoints, totalPointsGenOne, pokemonTypes);
    }

}
