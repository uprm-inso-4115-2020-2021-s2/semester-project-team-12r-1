package com.elmrtor.pkcalculator.ui.pkteam;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.elmrtor.pkcalculator.R;

public class PokemonTeamFragment extends Fragment {

    private PokemonTeamViewModel pokemonTeamViewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        pokemonTeamViewModel = new ViewModelProvider(this, new ViewModelProvider.NewInstanceFactory()).get(PokemonTeamViewModel.class);
        View root = inflater.inflate(R.layout.fragment_pokemon_team, container, false);
        final TextView textView = root.findViewById(R.id.text_pokemon_team);
        pokemonTeamViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
        // Inflate the layout for this fragment
        return root;
    }
}