package com.elmrtor.pkcalculator.ui.pkteam;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class PokemonTeamViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public PokemonTeamViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is Pokemon Team Fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }

}
