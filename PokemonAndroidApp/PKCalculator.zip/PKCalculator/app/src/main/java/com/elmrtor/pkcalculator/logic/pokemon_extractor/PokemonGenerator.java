package com.elmrtor.pkcalculator.logic.pokemon_extractor;

import android.app.Activity;

import com.elmrtor.pkcalculator.logic.pokemon_list.Pokemon;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class PokemonGenerator {

    private Activity currentActivity;

    public PokemonGenerator(Activity currentActivity) {
        this.currentActivity = currentActivity;
    }


    public List<Pokemon> getPokemonList(){
        return getJsonInfo();
    }


    private String readJsonFile() {
        String jsonInfo;
        try {
            InputStream is = currentActivity.getAssets().open("pokemon_json_data");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            jsonInfo = new String(buffer, "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return jsonInfo;
    }

    private List<Pokemon> getJsonInfo() {
        List<Pokemon> pokemonList = new ArrayList<>();
        try {
            JSONArray jsonAr = new JSONArray(readJsonFile());
            for (int i = 0; i < jsonAr.length(); ++i) {
                JSONObject jObj = jsonAr.getJSONObject(i);
                Iterator<String> keys = jObj.keys();
                Pokemon poke = new Pokemon();
                while (keys.hasNext()) {
                    switch(keys.next()) {
                        case "Type":
                            List<Pokemon.PokemonType> typeList = new ArrayList<>();
                            JSONArray jArr = jObj.getJSONArray("Type");
                            for (int j = 0; j < jArr.length(); ++j) {
                                switch (jArr.getString(j)) {
                                    case "bug":
                                        typeList.add(Pokemon.PokemonType.BUG);
                                        break;
                                    case "dragon":
                                        typeList.add(Pokemon.PokemonType.DRAGON);
                                        break;
                                    case "electric":
                                        typeList.add(Pokemon.PokemonType.ELECTRIC);
                                        break;
                                    case "fighting":
                                        typeList.add(Pokemon.PokemonType.FIGHTING);
                                        break;
                                    case "fire":
                                        typeList.add(Pokemon.PokemonType.FIRE);
                                        break;
                                    case "flying":
                                        typeList.add(Pokemon.PokemonType.FLYING);
                                        break;
                                    case "ghost":
                                        typeList.add(Pokemon.PokemonType.GHOST);
                                        break;
                                    case "grass":
                                        typeList.add(Pokemon.PokemonType.GRASS);
                                        break;
                                    case "ground":
                                        typeList.add(Pokemon.PokemonType.GROUND);
                                        break;
                                    case "ice":
                                        typeList.add(Pokemon.PokemonType.ICE);
                                        break;
                                    case "normal":
                                        typeList.add(Pokemon.PokemonType.NORMAL);
                                        break;
                                    case "poison":
                                        typeList.add(Pokemon.PokemonType.POISON);
                                        break;
                                    case "psychic":
                                        typeList.add(Pokemon.PokemonType.PSYCHIC);
                                        break;
                                    case "rock":
                                        typeList.add(Pokemon.PokemonType.ROCK);
                                        break;
                                    case "water":
                                        typeList.add(Pokemon.PokemonType.WATER);
                                        break;
                                }
                            }
                            poke.setPokemonTypes(typeList);
                            break;
                        case "Id":
                            poke.setPokemonId(jObj.getInt("Id"));
                            break;
                        case "PictureLink":
                            poke.setPokemonPictureLink(jObj.getString("PictureLink"));
                            break;
                        case "Name":
                            poke.setPokemonName(jObj.getString("Name"));
                            break;
                        case "TotalPoints":
                            poke.setTotalPoints(jObj.getInt("TotalPoints"));
                            break;
                        case "HealthPoints":
                            poke.setHealthPoints(jObj.getInt("HealthPoints"));
                            break;
                        case "AttackPoints":
                            poke.setAttackPoints(jObj.getInt("AttackPoints"));
                            break;
                        case "DefensePoints":
                            poke.setDefensePoints(jObj.getInt("DefensePoints"));
                            break;
                        case "SpAttackPoints":
                            poke.setSpecialAttack(jObj.getInt("SpAttackPoints"));
                            break;
                        case "SpDefensePoints":
                            poke.setSpecialDefense(jObj.getInt("SpDefensePoints"));
                            break;
                        case "Speed":
                            poke.setSpeedPoints(jObj.getInt("Speed"));
                            break;
                        case "TotalPointsGenOne":
                            poke.setTotalPointsGenOne(jObj.getInt("TotalPointsGenOne"));
                            break;
                    }
                }
                pokemonList.add(poke);
            }
        } catch (JSONException e){
            e.printStackTrace();
            return pokemonList;
        }
        return pokemonList;
    }

}
