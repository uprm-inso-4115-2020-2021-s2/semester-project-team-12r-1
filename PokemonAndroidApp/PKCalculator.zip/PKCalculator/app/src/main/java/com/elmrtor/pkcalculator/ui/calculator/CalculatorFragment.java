package com.elmrtor.pkcalculator.ui.calculator;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.elmrtor.pkcalculator.R;


public class CalculatorFragment extends Fragment {

    private CalculatorViewModel calculatorViewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        calculatorViewModel = new ViewModelProvider(this, new ViewModelProvider.NewInstanceFactory()).get(CalculatorViewModel.class);
        View root =  inflater.inflate(R.layout.fragment_calculator, container, false);
        final TextView textView = root.findViewById((R.id.text_calculator));
        calculatorViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
        // Inflate the layout for this fragment
        return root;
    }
}