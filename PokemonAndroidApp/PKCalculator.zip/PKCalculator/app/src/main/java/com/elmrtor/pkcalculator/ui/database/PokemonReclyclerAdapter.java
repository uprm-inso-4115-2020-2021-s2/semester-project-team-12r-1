package com.elmrtor.pkcalculator.ui.database;

import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.elmrtor.pkcalculator.databinding.PokemonBaseDataViewBinding;
import com.elmrtor.pkcalculator.logic.pokemon_list.Pokemon;

import java.util.List;



public class PokemonReclyclerAdapter extends RecyclerView.Adapter<PokemonReclyclerAdapter.ViewHolder>{

    private final List<Pokemon> pokemonList;

    public PokemonReclyclerAdapter(List<Pokemon> pkList) {
        pokemonList = pkList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        PokemonBaseDataViewBinding binding = PokemonBaseDataViewBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        Pokemon pokemon = pokemonList.get(position);
        holder.binding.setPokemon(pokemon);
        holder.binding.executePendingBindings();
    }

    @Override
    public int getItemCount() {
        return pokemonList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{

        public final PokemonBaseDataViewBinding binding;

        public ViewHolder(PokemonBaseDataViewBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

    }
}
