package com.elmrtor.pkcalculator.ui.database;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import android.content.Context;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.elmrtor.pkcalculator.R;
import com.elmrtor.pkcalculator.logic.pokemon_extractor.PokemonGenerator;
import com.elmrtor.pkcalculator.logic.pokemon_list.Pokemon;

import java.util.ArrayList;
import java.util.List;


public class DatabaseBrowserFragment extends Fragment {


    private DatabaseViewModel viewModel;
    private RecyclerView recyclerView;
    public List<Pokemon> pokemonList = new ArrayList<>();
    private PokemonReclyclerAdapter pokemonAdapter = new PokemonReclyclerAdapter(pokemonList);

    public DatabaseBrowserFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstancState) {
        super.onCreate(savedInstancState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

//        viewModel = new ViewModelProvider(this, new ViewModelProvider.NewInstanceFactory()).get(DatabaseViewModel.class);
//        View root = inflater.inflate(R.layout.fragment_database_browser, container, false);
//        View root inflater.inflate(R.)

        View root = inflater.inflate(R.layout.fragment_database_browser, container, false);

        recyclerView = (RecyclerView) root.findViewById(R.id.pk_list);

        if (savedInstanceState == null) {
            setPokemon(new PokemonGenerator(getActivity()).getPokemonList());
        }
        return root;
    }


    @Override
    public void onViewCreated(View view, Bundle onSavedInstanceState) {
        super.onViewCreated(view, onSavedInstanceState);

        Context context = view.getContext();
        if (recyclerView == null) {
            recyclerView = new RecyclerView(context);
//            recyclerView = (RecyclerView) view.findViewById(R.id.pk_list);
        }
        recyclerView.setLayoutManager(new LinearLayoutManager(context));
        recyclerView.setAdapter(pokemonAdapter);
    }

    public void setPokemon(List<Pokemon> pkList) {
        for (Pokemon p: pkList) {
            if (!pokemonList.contains(p)) {
                pokemonList.add(p);
                pokemonAdapter.notifyItemInserted(pokemonList.indexOf(p));
            }
        }
    }


}